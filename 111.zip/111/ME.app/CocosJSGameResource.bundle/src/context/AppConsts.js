
var AppConsts = {
};

AppConsts.DownloadTaskState = {
	NONE : 0,
	OPEN : 1,
	DOWNLOADING : 2,
	ERROR : 3,
	FINISH : 4,
	CANCEL : 5
}