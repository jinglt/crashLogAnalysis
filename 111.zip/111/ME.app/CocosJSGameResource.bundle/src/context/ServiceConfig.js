
var ServiceConfig = {
	mapService : "http://map.hi.jd.com",
	mapService2 : "http://192.168.149.158",
	localMapFileBase : "/jdmap/map"
};

var SC = ServiceConfig;
