var AppStyles = {
				font_normal : "Arial",
				font_title : "SimHei",
				font_normal_color : "#333333",
				font_tip_color : "#666666",
				font_weak_color : "#cccccc",
				font_title_color : "#FFFFFF",
				font_link_color : "#0000FF",
				font_marker_color : "#333333",
				split_color : "#e6e6e6",
				background_color : "#e0e0e0",
				exitTitle : "京东ME"

}