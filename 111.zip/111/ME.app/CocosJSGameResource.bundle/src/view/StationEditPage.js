var StationEditPage = PageView.extend({

	onCreate : function(){
		this.name = "stationPage";
		this.userInfo = UserService.getUserInfo();
	},
	
	onResume : function(){
		
	},

	onPause : function(){
		
	},

	createContentUI : function(){
		
	}
	

});